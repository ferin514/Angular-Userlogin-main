package com.UST.UserLoginSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
